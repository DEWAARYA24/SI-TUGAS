package com.f52123075.situgas.views;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.f52123075.situgas.R;
import com.f52123075.situgas.adapters.TaskAdapter;
import com.f52123075.situgas.controllers.TaskController;
import com.f52123075.situgas.models.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment implements TaskAdapter.OnTaskClickListener {
    private RecyclerView recyclerView;
    private TaskAdapter taskAdapter;
    private FloatingActionButton fabAdd;
    private TaskController taskController;
    private List<Task> taskList;
    private View emptyView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        taskController = new TaskController(requireContext());

        initViews(view);
        setupRecyclerView();
        setupListeners();
        loadTasks();

        return view;
    }

    private void initViews(View view) {
        recyclerView = view.findViewById(R.id.recyclerViewTasks);
        fabAdd = view.findViewById(R.id.fabAddTask);
        emptyView = view.findViewById(R.id.emptyView);
    }

    private void setupRecyclerView() {
        taskList = new ArrayList<>();
        taskAdapter = new TaskAdapter(taskList, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        recyclerView.setAdapter(taskAdapter);
    }

    private void setupListeners() {
        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), AddTaskActivity.class);
            startActivity(intent);
        });
    }

    private void loadTasks() {
        List<Task> tasks = taskController.getAllTasks();
        if (tasks != null && !tasks.isEmpty()) {
            taskList.clear();
            taskList.addAll(tasks);
            taskAdapter.notifyDataSetChanged();

            emptyView.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        } else {
            emptyView.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        }
    }

    @Override
    public void onTaskClick(Task task) {
        // Buka detail/edit task
        Intent intent = new Intent(requireContext(), AddTaskActivity.class);
        intent.putExtra("TASK_ID", task.getId());
        intent.putExtra("MODE", "EDIT");
        startActivity(intent);
    }

    @Override
    public void onTaskLongClick(Task task) {
        // Tampilkan dialog opsi
        showTaskOptionsDialog(task);
    }

    private void showTaskOptionsDialog(Task task) {
        String[] options = {"Edit", "Ubah Status", "Hapus"};

        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle(task.getTitle())
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0: // Edit
                            onTaskClick(task);
                            break;
                        case 1: // Ubah Status
                            showStatusDialog(task);
                            break;
                        case 2: // Hapus
                            showDeleteConfirmation(task);
                            break;
                    }
                })
                .show();
    }

    private void showStatusDialog(Task task) {
        String[] statuses = {"Pending", "In Progress", "Completed"};
        int currentStatus = task.getStatus();

        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Ubah Status")
                .setSingleChoiceItems(statuses, currentStatus, (dialog, which) -> {
                    TaskController.TaskResult result = taskController.updateTaskStatus(task.getId(), which);
                    Toast.makeText(requireContext(), result.message, Toast.LENGTH_SHORT).show();

                    if (result.success) {
                        loadTasks();
                    }
                    dialog.dismiss();
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void showDeleteConfirmation(Task task) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Hapus Tugas")
                .setMessage("Apakah Anda yakin ingin menghapus tugas \"" + task.getTitle() + "\"?")
                .setPositiveButton("Hapus", (dialog, which) -> {
                    TaskController.TaskResult result = taskController.deleteTask(task.getId());
                    Toast.makeText(requireContext(), result.message, Toast.LENGTH_SHORT).show();

                    if (result.success) {
                        loadTasks();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadTasks(); // Refresh data saat kembali ke fragment
    }
}
