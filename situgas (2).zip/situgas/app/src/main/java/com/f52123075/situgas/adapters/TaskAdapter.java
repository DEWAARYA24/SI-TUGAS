package com.f52123075.situgas.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.f52123075.situgas.R;
import com.f52123075.situgas.models.Task;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {
    private List<Task> taskList;
    private OnTaskClickListener listener;

    public interface OnTaskClickListener {
        void onTaskClick(Task task);
        void onTaskLongClick(Task task);
    }

    public TaskAdapter(List<Task> taskList, OnTaskClickListener listener) {
        this.taskList = taskList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_task, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.bind(task);
    }

    @Override
    public int getItemCount() {
        return taskList != null ? taskList.size() : 0;
    }

    public void updateTasks(List<Task> newTasks) {
        this.taskList = newTasks;
        notifyDataSetChanged();
    }

    class TaskViewHolder extends RecyclerView.ViewHolder {
        private CardView cardView;
        private View statusIndicator;
        private TextView tvTitle;
        private TextView tvDescription;
        private TextView tvDeadline;
        private TextView tvStatus;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardTask);
            statusIndicator = itemView.findViewById(R.id.statusIndicator);
            tvTitle = itemView.findViewById(R.id.tvTaskTitle);
            tvDescription = itemView.findViewById(R.id.tvTaskDescription);
            tvDeadline = itemView.findViewById(R.id.tvTaskDeadline);
            tvStatus = itemView.findViewById(R.id.tvTaskStatus);

            // Click listener
            cardView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onTaskClick(taskList.get(position));
                }
            });

            // Long click listener
            cardView.setOnLongClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onTaskLongClick(taskList.get(position));
                    return true;
                }
                return false;
            });
        }

        public void bind(Task task) {
            tvTitle.setText(task.getTitle());

            // Description
            if (task.getDescription() != null && !task.getDescription().isEmpty()) {
                tvDescription.setText(task.getDescription());
                tvDescription.setVisibility(View.VISIBLE);
            } else {
                tvDescription.setVisibility(View.GONE);
            }

            // Deadline dengan format lebih readable
            tvDeadline.setText("Deadline: " + formatDeadline(task.getDeadline()));

            // Status text dan color
            tvStatus.setText(task.getStatusText());

            // Set warna berdasarkan status
            int color = task.getStatusColor();
            statusIndicator.setBackgroundColor(color);
            tvStatus.setTextColor(color);

            // Highlight jika deadline sudah dekat
            if (isDeadlineNear(task.getDeadline())) {
                cardView.setCardBackgroundColor(Color.parseColor("#FFF3E0")); // Light orange
            } else {
                cardView.setCardBackgroundColor(Color.WHITE);
            }
        }

        private String formatDeadline(String deadline) {
            try {
                SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                SimpleDateFormat outputFormat = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());
                Date date = inputFormat.parse(deadline);
                return date != null ? outputFormat.format(date) : deadline;
            } catch (ParseException e) {
                return deadline;
            }
        }

        private boolean isDeadlineNear(String deadline) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                Date deadlineDate = sdf.parse(deadline);
                if (deadlineDate != null) {
                    long diff = deadlineDate.getTime() - System.currentTimeMillis();
                    long daysDiff = diff / (1000 * 60 * 60 * 24);
                    return daysDiff <= 2 && daysDiff >= 0; // 2 hari atau kurang
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
            return false;
        }
    }
}