package com.f52123075.situgas.models;

public class Task {
    private int id;
    private String title;
    private String description;
    private String deadline;
    private int status; // 0=pending, 1=in progress, 2=completed
    private int userId;
    private long createdAt;

    public Task() {}

    public Task(String title, String description, String deadline, int status, int userId) {
        this.title = title;
        this.description = description;
        this.deadline = deadline;
        this.status = status;
        this.userId = userId;
        this.createdAt = System.currentTimeMillis();
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDeadline() { return deadline; }
    public void setDeadline(String deadline) { this.deadline = deadline; }

    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }

    // Helper method untuk mendapatkan warna status
    public int getStatusColor() {
        switch (status) {
            case 0: return 0xFFFF9800; // Orange - Pending
            case 1: return 0xFF2196F3; // Blue - In Progress
            case 2: return 0xFF4CAF50; // Green - Completed
            default: return 0xFF757575; // Gray - Default
        }
    }

    public String getStatusText() {
        switch (status) {
            case 0: return "Pending";
            case 1: return "In Progress";
            case 2: return "Completed";
            default: return "Unknown";
        }
    }
}