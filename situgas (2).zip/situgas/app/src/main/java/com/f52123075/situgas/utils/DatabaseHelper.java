package com.f52123075.situgas.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.f52123075.situgas.models.Task;
import com.f52123075.situgas.models.User;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "SiTugas.db";
    private static final int DATABASE_VERSION = 1;

    // Table Users
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_EMAIL = "email";
    private static final String COL_PASSWORD = "password";
    private static final String COL_PHOTO_PATH = "photo_path";

    // Table Tasks
    private static final String TABLE_TASKS = "tasks";
    private static final String COL_TASK_ID = "id";
    private static final String COL_TITLE = "title";
    private static final String COL_DESCRIPTION = "description";
    private static final String COL_DEADLINE = "deadline";
    private static final String COL_STATUS = "status";
    private static final String COL_USER_ID_FK = "user_id";
    private static final String COL_CREATED_AT = "created_at";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users Table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT NOT NULL, " +
                COL_EMAIL + " TEXT UNIQUE NOT NULL, " +
                COL_PASSWORD + " TEXT NOT NULL, " +
                COL_PHOTO_PATH + " TEXT)";
        db.execSQL(createUsersTable);

        // Create Tasks Table
        String createTasksTable = "CREATE TABLE " + TABLE_TASKS + " (" +
                COL_TASK_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_TITLE + " TEXT NOT NULL, " +
                COL_DESCRIPTION + " TEXT, " +
                COL_DEADLINE + " TEXT NOT NULL, " +
                COL_STATUS + " INTEGER DEFAULT 0, " +
                COL_USER_ID_FK + " INTEGER NOT NULL, " +
                COL_CREATED_AT + " INTEGER, " +
                "FOREIGN KEY(" + COL_USER_ID_FK + ") REFERENCES " +
                TABLE_USERS + "(" + COL_USER_ID + "))";
        db.execSQL(createTasksTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TASKS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // ==================== USER OPERATIONS ====================
    public long registerUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, user.getUsername());
        values.put(COL_EMAIL, user.getEmail());
        values.put(COL_PASSWORD, user.getPassword());

        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result;
    }

    public User loginUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        User user = null;

        Cursor cursor = db.query(TABLE_USERS, null,
                COL_EMAIL + "=? AND " + COL_PASSWORD + "=?",
                new String[]{email, password}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            user = new User();
            user.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_USER_ID)));
            user.setUsername(cursor.getString(cursor.getColumnIndexOrThrow(COL_USERNAME)));
            user.setEmail(cursor.getString(cursor.getColumnIndexOrThrow(COL_EMAIL)));
            user.setPhotoPath(cursor.getString(cursor.getColumnIndexOrThrow(COL_PHOTO_PATH)));
            cursor.close();
        }

        db.close();
        return user;
    }

    public boolean isEmailExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null, COL_EMAIL + "=?",
                new String[]{email}, null, null, null);
        boolean exists = cursor != null && cursor.getCount() > 0;
        if (cursor != null) cursor.close();
        db.close();
        return exists;
    }

    public boolean updateUserPhoto(int userId, String photoPath) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_PHOTO_PATH, photoPath);

        int result = db.update(TABLE_USERS, values, COL_USER_ID + "=?",
                new String[]{String.valueOf(userId)});
        db.close();
        return result > 0;
    }

    public User getUserById(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        User user = null;

        Cursor cursor = db.query(TABLE_USERS, null, COL_USER_ID + "=?",
                new String[]{String.valueOf(userId)}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            user = new User();
            user.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_USER_ID)));
            user.setUsername(cursor.getString(cursor.getColumnIndexOrThrow(COL_USERNAME)));
            user.setEmail(cursor.getString(cursor.getColumnIndexOrThrow(COL_EMAIL)));
            user.setPhotoPath(cursor.getString(cursor.getColumnIndexOrThrow(COL_PHOTO_PATH)));
            cursor.close();
        }

        db.close();
        return user;
    }

    // ==================== TASK OPERATIONS (CRUD) ====================
    public long createTask(Task task) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TITLE, task.getTitle());
        values.put(COL_DESCRIPTION, task.getDescription());
        values.put(COL_DEADLINE, task.getDeadline());
        values.put(COL_STATUS, task.getStatus());
        values.put(COL_USER_ID_FK, task.getUserId());
        values.put(COL_CREATED_AT, System.currentTimeMillis());

        long result = db.insert(TABLE_TASKS, null, values);
        db.close();
        return result;
    }

    public List<Task> getAllTasksByUser(int userId) {
        List<Task> taskList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_TASKS, null, COL_USER_ID_FK + "=?",
                new String[]{String.valueOf(userId)}, null, null,
                COL_CREATED_AT + " DESC");

        if (cursor != null && cursor.moveToFirst()) {
            do {
                Task task = new Task();
                task.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_TASK_ID)));
                task.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COL_TITLE)));
                task.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(COL_DESCRIPTION)));
                task.setDeadline(cursor.getString(cursor.getColumnIndexOrThrow(COL_DEADLINE)));
                task.setStatus(cursor.getInt(cursor.getColumnIndexOrThrow(COL_STATUS)));
                task.setUserId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_USER_ID_FK)));
                task.setCreatedAt(cursor.getLong(cursor.getColumnIndexOrThrow(COL_CREATED_AT)));
                taskList.add(task);
            } while (cursor.moveToNext());
            cursor.close();
        }

        db.close();
        return taskList;
    }

    public Task getTaskById(int taskId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Task task = null;

        Cursor cursor = db.query(TABLE_TASKS, null, COL_TASK_ID + "=?",
                new String[]{String.valueOf(taskId)}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            task = new Task();
            task.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_TASK_ID)));
            task.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COL_TITLE)));
            task.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(COL_DESCRIPTION)));
            task.setDeadline(cursor.getString(cursor.getColumnIndexOrThrow(COL_DEADLINE)));
            task.setStatus(cursor.getInt(cursor.getColumnIndexOrThrow(COL_STATUS)));
            task.setUserId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_USER_ID_FK)));
            task.setCreatedAt(cursor.getLong(cursor.getColumnIndexOrThrow(COL_CREATED_AT)));
            cursor.close();
        }

        db.close();
        return task;
    }

    public boolean updateTask(Task task) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TITLE, task.getTitle());
        values.put(COL_DESCRIPTION, task.getDescription());
        values.put(COL_DEADLINE, task.getDeadline());
        values.put(COL_STATUS, task.getStatus());

        int result = db.update(TABLE_TASKS, values, COL_TASK_ID + "=?",
                new String[]{String.valueOf(task.getId())});
        db.close();
        return result > 0;
    }

    public boolean deleteTask(int taskId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_TASKS, COL_TASK_ID + "=?",
                new String[]{String.valueOf(taskId)});
        db.close();
        return result > 0;
    }

    // Method untuk mendapatkan tugas yang mendekati deadline
    public List<Task> getTasksNearDeadline(int userId, long daysBefore) {
        List<Task> taskList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        long currentTime = System.currentTimeMillis();
        long checkTime = currentTime + (daysBefore * 24 * 60 * 60 * 1000);

        Cursor cursor = db.query(TABLE_TASKS, null,
                COL_USER_ID_FK + "=? AND " + COL_STATUS + "!=2",
                new String[]{String.valueOf(userId)}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                Task task = new Task();
                task.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_TASK_ID)));
                task.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COL_TITLE)));
                task.setDeadline(cursor.getString(cursor.getColumnIndexOrThrow(COL_DEADLINE)));
                taskList.add(task);
            } while (cursor.moveToNext());
            cursor.close();
        }

        db.close();
        return taskList;
    }
}