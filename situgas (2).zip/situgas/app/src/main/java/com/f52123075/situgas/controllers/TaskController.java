package com.f52123075.situgas.controllers;

import android.content.Context;
import com.f52123075.situgas.models.Task;
import com.f52123075.situgas.utils.DatabaseHelper;
import com.f52123075.situgas.utils.NotificationHelper;
import com.f52123075.situgas.utils.SessionManager;
import java.util.List;

public class TaskController {
    private DatabaseHelper dbHelper;
    private NotificationHelper notificationHelper;
    private SessionManager sessionManager;
    private Context context;

    public TaskController(Context context) {
        this.context = context;
        this.dbHelper = new DatabaseHelper(context);
        this.notificationHelper = new NotificationHelper(context);
        this.sessionManager = new SessionManager(context);
    }

    // Create task baru
    public TaskResult createTask(String title, String description, String deadline, int status) {
        TaskResult result = new TaskResult();

        // Validasi input
        if (title == null || title.trim().isEmpty()) {
            result.success = false;
            result.message = "Judul tugas tidak boleh kosong";
            return result;
        }

        if (deadline == null || deadline.trim().isEmpty()) {
            result.success = false;
            result.message = "Deadline tidak boleh kosong";
            return result;
        }

        // Dapatkan user ID yang sedang login
        int userId = sessionManager.getUserId();
        if (userId == -1) {
            result.success = false;
            result.message = "User tidak terautentikasi";
            return result;
        }

        // Buat task
        Task task = new Task(title, description, deadline, status, userId);
        long taskId = dbHelper.createTask(task);

        if (taskId != -1) {
            task.setId((int) taskId);

            // Set notifikasi
            notificationHelper.scheduleTaskNotification(task);

            result.success = true;
            result.message = "Tugas berhasil ditambahkan";
            result.task = task;
        } else {
            result.success = false;
            result.message = "Gagal menambahkan tugas";
        }

        return result;
    }

    // Read - Dapatkan semua task user
    public List<Task> getAllTasks() {
        int userId = sessionManager.getUserId();
        if (userId == -1) {
            return null;
        }
        return dbHelper.getAllTasksByUser(userId);
    }

    // Read - Dapatkan task berdasarkan ID
    public Task getTaskById(int taskId) {
        return dbHelper.getTaskById(taskId);
    }

    // Update task
    public TaskResult updateTask(int taskId, String title, String description, String deadline, int status) {
        TaskResult result = new TaskResult();

        // Validasi input
        if (title == null || title.trim().isEmpty()) {
            result.success = false;
            result.message = "Judul tugas tidak boleh kosong";
            return result;
        }

        if (deadline == null || deadline.trim().isEmpty()) {
            result.success = false;
            result.message = "Deadline tidak boleh kosong";
            return result;
        }

        // Dapatkan task yang akan diupdate
        Task task = dbHelper.getTaskById(taskId);
        if (task == null) {
            result.success = false;
            result.message = "Tugas tidak ditemukan";
            return result;
        }

        // Update task
        task.setTitle(title);
        task.setDescription(description);
        task.setDeadline(deadline);
        task.setStatus(status);

        boolean updated = dbHelper.updateTask(task);

        if (updated) {
            // Cancel notifikasi lama dan buat yang baru
            notificationHelper.cancelTaskNotification(taskId);
            notificationHelper.scheduleTaskNotification(task);

            result.success = true;
            result.message = "Tugas berhasil diperbarui";
            result.task = task;
        } else {
            result.success = false;
            result.message = "Gagal memperbarui tugas";
        }

        return result;
    }

    // Delete task
    public TaskResult deleteTask(int taskId) {
        TaskResult result = new TaskResult();

        // Cancel notifikasi
        notificationHelper.cancelTaskNotification(taskId);

        boolean deleted = dbHelper.deleteTask(taskId);

        if (deleted) {
            result.success = true;
            result.message = "Tugas berhasil dihapus";
        } else {
            result.success = false;
            result.message = "Gagal menghapus tugas";
        }

        return result;
    }

    // Update status task
    public TaskResult updateTaskStatus(int taskId, int status) {
        TaskResult result = new TaskResult();

        Task task = dbHelper.getTaskById(taskId);
        if (task == null) {
            result.success = false;
            result.message = "Tugas tidak ditemukan";
            return result;
        }

        task.setStatus(status);
        boolean updated = dbHelper.updateTask(task);

        if (updated) {
            result.success = true;
            result.message = "Status tugas berhasil diperbarui";
            result.task = task;
        } else {
            result.success = false;
            result.message = "Gagal memperbarui status";
        }

        return result;
    }

    // Inner class untuk result
    public static class TaskResult {
        public boolean success;
        public String message;
        public Task task;
    }
}