package com.f52123075.situgas.utils;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.f52123075.situgas.R;
import com.f52123075.situgas.models.Task;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class NotificationHelper {
    private static final String CHANNEL_ID = "situgas_channel";
    private static final String CHANNEL_NAME = "SiTugas Notifications";
    private static final String CHANNEL_DESC = "Notifikasi untuk tenggat waktu tugas";

    private Context context;
    private NotificationManager notificationManager;

    public NotificationHelper(Context context) {
        this.context = context;
        notificationManager = (NotificationManager)
                context.getSystemService(Context.NOTIFICATION_SERVICE);
        createNotificationChannel();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription(CHANNEL_DESC);
            notificationManager.createNotificationChannel(channel);
        }
    }

    public void scheduleTaskNotification(Task task) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date deadlineDate = sdf.parse(task.getDeadline());

            if (deadlineDate != null) {
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(deadlineDate);
                calendar.set(Calendar.HOUR_OF_DAY, 9);
                calendar.set(Calendar.MINUTE, 0);
                calendar.set(Calendar.SECOND, 0);

                // Notifikasi 1 hari sebelum deadline
                Calendar notifTime = (Calendar) calendar.clone();
                notifTime.add(Calendar.DAY_OF_YEAR, -1);

                if (notifTime.getTimeInMillis() > System.currentTimeMillis()) {
                    setAlarm(task.getId(), task.getTitle(), notifTime.getTimeInMillis());
                }

                // Notifikasi pada hari deadline
                if (calendar.getTimeInMillis() > System.currentTimeMillis()) {
                    setAlarm(task.getId() + 10000, task.getTitle(), calendar.getTimeInMillis());
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private void setAlarm(int requestCode, String taskTitle, long timeInMillis) {
        Intent intent = new Intent(context, NotificationReceiver.class);
        intent.putExtra("taskTitle", taskTitle);
        intent.putExtra("notificationId", requestCode);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager alarmManager = (AlarmManager)
                context.getSystemService(Context.ALARM_SERVICE);

        if (alarmManager != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent);
            } else {
                alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent);
            }
        }
    }

    public void cancelTaskNotification(int taskId) {
        Intent intent = new Intent(context, NotificationReceiver.class);

        // Cancel notifikasi 1 hari sebelum
        PendingIntent pendingIntent1 = PendingIntent.getBroadcast(
                context, taskId, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // Cancel notifikasi hari deadline
        PendingIntent pendingIntent2 = PendingIntent.getBroadcast(
                context, taskId + 10000, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager alarmManager = (AlarmManager)
                context.getSystemService(Context.ALARM_SERVICE);

        if (alarmManager != null) {
            alarmManager.cancel(pendingIntent1);
            alarmManager.cancel(pendingIntent2);
        }
    }

    // BroadcastReceiver untuk menampilkan notifikasi
    public static class NotificationReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String taskTitle = intent.getStringExtra("taskTitle");
            int notificationId = intent.getIntExtra("notificationId", 0);

            NotificationManager notificationManager = (NotificationManager)
                    context.getSystemService(Context.NOTIFICATION_SERVICE);

            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle("Pengingat Tugas")
                    .setContentText("Tugas: " + taskTitle + " segera deadline!")
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true);

            if (notificationManager != null) {
                notificationManager.notify(notificationId, builder.build());
            }
        }
    }
}
