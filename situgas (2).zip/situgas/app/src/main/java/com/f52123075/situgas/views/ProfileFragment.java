package com.f52123075.situgas.views;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.f52123075.situgas.R;
import com.f52123075.situgas.controllers.AuthController;
import com.f52123075.situgas.controllers.TaskController;
import com.f52123075.situgas.models.Task;
import com.f52123075.situgas.models.User;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;

public class ProfileFragment extends Fragment {
    private ImageView ivProfilePhoto;
    private TextView tvUsername, tvEmail;
    private TextView tvTotalTasks, tvCompletedTasks, tvPendingTasks;
    private View btnChangePhoto, btnLogout, btnEditProfile, btnSettings, btnAbout;

    private AuthController authController;
    private TaskController taskController;
    private ActivityResultLauncher<Intent> imagePickerLauncher;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        authController = new AuthController(requireContext());
        taskController = new TaskController(requireContext());

        initViews(view);
        setupImagePicker();
        setupListeners();
        loadUserData();
        loadStatistics();

        return view;
    }

    private void initViews(View view) {
        ivProfilePhoto = view.findViewById(R.id.ivProfilePhoto);
        tvUsername = view.findViewById(R.id.tvUsername);
        tvEmail = view.findViewById(R.id.tvEmail);

        tvTotalTasks = view.findViewById(R.id.tvTotalTasks);
        tvCompletedTasks = view.findViewById(R.id.tvCompletedTasks);
        tvPendingTasks = view.findViewById(R.id.tvPendingTasks);

        btnChangePhoto = view.findViewById(R.id.btnChangePhoto);
        btnLogout = view.findViewById(R.id.btnLogout);
        btnEditProfile = view.findViewById(R.id.btnEditProfile);
        btnSettings = view.findViewById(R.id.btnSettings);
        btnAbout = view.findViewById(R.id.btnAbout);
    }

    private void setupImagePicker() {
        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Uri imageUri = result.getData().getData();
                        if (imageUri != null) {
                            handleImageSelected(imageUri);
                        }
                    }
                });
    }

    private void setupListeners() {
        btnChangePhoto.setOnClickListener(v -> openImagePicker());

        btnLogout.setOnClickListener(v -> showLogoutConfirmation());

        btnEditProfile.setOnClickListener(v -> {
            Toast.makeText(requireContext(), "Edit Profile - Coming Soon", Toast.LENGTH_SHORT).show();
        });

        btnSettings.setOnClickListener(v -> {
            Toast.makeText(requireContext(), "Settings - Coming Soon", Toast.LENGTH_SHORT).show();
        });

        btnAbout.setOnClickListener(v -> showAboutDialog());
    }

    private void loadUserData() {
        User user = authController.getCurrentUser();
        if (user != null) {
            tvUsername.setText(user.getUsername());
            tvEmail.setText(user.getEmail());

            if (user.getPhotoPath() != null && !user.getPhotoPath().isEmpty()) {
                try {
                    Uri photoUri = Uri.parse(user.getPhotoPath());
                    InputStream imageStream = requireContext().getContentResolver().openInputStream(photoUri);
                    Bitmap bitmap = BitmapFactory.decodeStream(imageStream);
                    ivProfilePhoto.setImageBitmap(bitmap);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void loadStatistics() {
        List<Task> tasks = taskController.getAllTasks();

        if (tasks != null) {
            int total = tasks.size();
            int completed = 0;
            int pending = 0;

            for (Task task : tasks) {
                if (task.getStatus() == 2) { // Completed
                    completed++;
                } else if (task.getStatus() == 0) { // Pending
                    pending++;
                }
            }

            tvTotalTasks.setText(String.valueOf(total));
            tvCompletedTasks.setText(String.valueOf(completed));
            tvPendingTasks.setText(String.valueOf(pending));
        } else {
            tvTotalTasks.setText("0");
            tvCompletedTasks.setText("0");
            tvPendingTasks.setText("0");
        }
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        imagePickerLauncher.launch(intent);
    }

    private void handleImageSelected(Uri imageUri) {
        try {
            InputStream imageStream = requireContext().getContentResolver().openInputStream(imageUri);
            Bitmap bitmap = BitmapFactory.decodeStream(imageStream);
            ivProfilePhoto.setImageBitmap(bitmap);

            String photoPath = imageUri.toString();
            boolean updated = authController.updateProfilePhoto(photoPath);

            if (updated) {
                Toast.makeText(requireContext(), "Foto profil berhasil diubah", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(requireContext(), "Gagal mengubah foto profil", Toast.LENGTH_SHORT).show();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Toast.makeText(requireContext(), "Gagal membaca foto", Toast.LENGTH_SHORT).show();
        }
    }

    private void showLogoutConfirmation() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Logout")
                .setMessage("Apakah Anda yakin ingin keluar?")
                .setPositiveButton("Ya", (dialog, which) -> {
                    authController.logout();
                    Intent intent = new Intent(requireContext(), LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    requireActivity().finish();
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void showAboutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Tentang SiTugas")
                .setMessage("SiTugas - Sistem Informasi Tugas\n\n" +
                        "Versi: 1.0\n\n" +
                        "Aplikasi manajemen tugas yang membantu Anda mengorganisir " +
                        "dan menyelesaikan tugas dengan lebih efisien.\n\n" +
                        "© 2025 SiTugas")
                .setPositiveButton("OK", null)
                .show();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadStatistics();
    }
}