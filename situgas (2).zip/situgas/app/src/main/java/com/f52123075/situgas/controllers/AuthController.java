package com.f52123075.situgas.controllers;

import android.content.Context;
import com.f52123075.situgas.models.User;
import com.f52123075.situgas.utils.DatabaseHelper;
import com.f52123075.situgas.utils.SessionManager;
import com.f52123075.situgas.utils.ValidationHelper;

public class AuthController {
    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private Context context;

    public AuthController(Context context) {
        this.context = context;
        this.dbHelper = new DatabaseHelper(context);
        this.sessionManager = new SessionManager(context);
    }

    // Register user baru
    public RegisterResult register(String username, String email, String password, String confirmPassword) {
        RegisterResult result = new RegisterResult();

        // Validasi input
        String usernameError = ValidationHelper.getUsernameError(username);
        if (usernameError != null) {
            result.success = false;
            result.message = usernameError;
            return result;
        }

        String emailError = ValidationHelper.getEmailError(email);
        if (emailError != null) {
            result.success = false;
            result.message = emailError;
            return result;
        }

        String passwordError = ValidationHelper.getPasswordError(password);
        if (passwordError != null) {
            result.success = false;
            result.message = passwordError;
            return result;
        }

        if (!password.equals(confirmPassword)) {
            result.success = false;
            result.message = "Password dan konfirmasi password tidak sama";
            return result;
        }

        // Cek apakah email sudah terdaftar
        if (dbHelper.isEmailExists(email)) {
            result.success = false;
            result.message = "Email sudah terdaftar";
            return result;
        }

        // Simpan user ke database
        User user = new User(username, email, password);
        long userId = dbHelper.registerUser(user);

        if (userId != -1) {
            result.success = true;
            result.message = "Registrasi berhasil";
            result.userId = (int) userId;
        } else {
            result.success = false;
            result.message = "Registrasi gagal. Silakan coba lagi";
        }

        return result;
    }

    // Login user
    public LoginResult login(String email, String password) {
        LoginResult result = new LoginResult();

        // Validasi input
        if (email == null || email.isEmpty()) {
            result.success = false;
            result.message = "Email tidak boleh kosong";
            return result;
        }

        if (password == null || password.isEmpty()) {
            result.success = false;
            result.message = "Password tidak boleh kosong";
            return result;
        }

        // Cek kredensial
        User user = dbHelper.loginUser(email, password);

        if (user != null) {
            // Buat session
            sessionManager.createLoginSession(user.getId(), user.getUsername(), user.getEmail());

            result.success = true;
            result.message = "Login berhasil";
            result.user = user;
        } else {
            result.success = false;
            result.message = "Email atau password salah";
        }

        return result;
    }

    // Logout user
    public void logout() {
        sessionManager.logout();
    }

    // Cek apakah user sudah login
    public boolean isLoggedIn() {
        return sessionManager.isLoggedIn();
    }

    // Dapatkan user ID yang sedang login
    public int getCurrentUserId() {
        return sessionManager.getUserId();
    }

    // Dapatkan user yang sedang login
    public User getCurrentUser() {
        if (!isLoggedIn()) {
            return null;
        }
        return dbHelper.getUserById(getCurrentUserId());
    }

    // Update foto profil
    public boolean updateProfilePhoto(String photoPath) {
        int userId = getCurrentUserId();
        if (userId == -1) {
            return false;
        }
        return dbHelper.updateUserPhoto(userId, photoPath);
    }

    // Inner classes untuk result
    public static class RegisterResult {
        public boolean success;
        public String message;
        public int userId;
    }

    public static class LoginResult {
        public boolean success;
        public String message;
        public User user;
    }
}