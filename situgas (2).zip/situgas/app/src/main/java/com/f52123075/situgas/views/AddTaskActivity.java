package com.f52123075.situgas.views;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.f52123075.situgas.R;
import com.f52123075.situgas.controllers.TaskController;
import com.f52123075.situgas.models.Task;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddTaskActivity extends AppCompatActivity {
    private EditText etTitle, etDescription, etDeadline;
    private Spinner spinnerStatus;
    private Button btnSave;
    private TaskController taskController;
    private Calendar calendar;
    private String mode = "ADD"; // ADD or EDIT
    private int taskId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        taskController = new TaskController(this);
        calendar = Calendar.getInstance();

        // Cek mode (tambah atau edit)
        if (getIntent().hasExtra("MODE")) {
            mode = getIntent().getStringExtra("MODE");
            taskId = getIntent().getIntExtra("TASK_ID", -1);
        }

        initViews();
        setupToolbar();
        setupSpinner();
        setupListeners();

        // Jika mode edit, load data task
        if (mode.equals("EDIT") && taskId != -1) {
            loadTaskData();
        }
    }

    private void initViews() {
        etTitle = findViewById(R.id.etTitle);
        etDescription = findViewById(R.id.etDescription);
        etDeadline = findViewById(R.id.etDeadline);
        spinnerStatus = findViewById(R.id.spinnerStatus);
        btnSave = findViewById(R.id.btnSave);
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(mode.equals("ADD") ? "Tambah Tugas" : "Edit Tugas");
        }
    }

    private void setupSpinner() {
        String[] statuses = {"Pending", "In Progress", "Completed"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, statuses);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerStatus.setAdapter(adapter);
    }

    private void setupListeners() {
        etDeadline.setOnClickListener(v -> showDatePicker());

        btnSave.setOnClickListener(v -> {
            if (mode.equals("ADD")) {
                handleAddTask();
            } else {
                handleUpdateTask();
            }
        });
    }

    private void showDatePicker() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    calendar.set(Calendar.YEAR, year);
                    calendar.set(Calendar.MONTH, month);
                    calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    updateDeadlineText();
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
        datePickerDialog.show();
    }

    private void updateDeadlineText() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        etDeadline.setText(sdf.format(calendar.getTime()));
    }

    private void handleAddTask() {
        String title = etTitle.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        String deadline = etDeadline.getText().toString().trim();
        int status = spinnerStatus.getSelectedItemPosition();

        TaskController.TaskResult result = taskController.createTask(
                title, description, deadline, status);

        Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show();

        if (result.success) {
            finish(); // Kembali ke HomeFragment
        }
    }

    private void handleUpdateTask() {
        String title = etTitle.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        String deadline = etDeadline.getText().toString().trim();
        int status = spinnerStatus.getSelectedItemPosition();

        TaskController.TaskResult result = taskController.updateTask(
                taskId, title, description, deadline, status);

        Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show();

        if (result.success) {
            finish(); // Kembali ke HomeFragment
        }
    }

    private void loadTaskData() {
        Task task = taskController.getTaskById(taskId);
        if (task != null) {
            etTitle.setText(task.getTitle());
            etDescription.setText(task.getDescription());
            etDeadline.setText(task.getDeadline());
            spinnerStatus.setSelection(task.getStatus());
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}