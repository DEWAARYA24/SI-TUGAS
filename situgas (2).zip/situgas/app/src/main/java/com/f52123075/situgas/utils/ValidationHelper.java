package com.f52123075.situgas.utils;

import android.util.Patterns;

public class ValidationHelper {

    public static boolean isValidEmail(String email) {
        return email != null && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    public static boolean isValidPassword(String password) {
        return password != null && password.length() >= 6;
    }

    public static boolean isValidUsername(String username) {
        return username != null && username.length() >= 3;
    }

    public static String getPasswordError(String password) {
        if (password == null || password.isEmpty()) {
            return "Password tidak boleh kosong";
        }
        if (password.length() < 6) {
            return "Password minimal 6 karakter";
        }
        return null;
    }

    public static String getUsernameError(String username) {
        if (username == null || username.isEmpty()) {
            return "Username tidak boleh kosong";
        }
        if (username.length() < 3) {
            return "Username minimal 3 karakter";
        }
        return null;
    }

    public static String getEmailError(String email) {
        if (email == null || email.isEmpty()) {
            return "Email tidak boleh kosong";
        }
        if (!isValidEmail(email)) {
            return "Format email tidak valid";
        }
        return null;
    }
}